const fetchUserData = (input,companyName) =>{
  const promise1 = new Promise((resolve, reject) =>{
          if(input == 1){
              resolve(
                  {
                    id:101,
                    name:"kiran",
                    address: "hyderabad"
                  }
              )
          }
          else{
            reject("Invalid input")
          }
  })

  const promise2 = new Promise((resolve, reject) =>{

    if(companyName == "XYZ"){
       resolve ( {
           name: "xyz",
           location:"hyderabad"
       })
    }

    if(companyName == "ABC"){
     resolve({
       name: "abc",
       location:"banglore"
     })
    }
    else{
     reject("This company info is not available")
    }

})
  return [promise1,promise2]

}

var promises = fetchUserData(1,"mshcjds");

Promise.all(promises).then((response) =>{
    console.log(response)
},
(error) =>{
  console.log(error)
})
