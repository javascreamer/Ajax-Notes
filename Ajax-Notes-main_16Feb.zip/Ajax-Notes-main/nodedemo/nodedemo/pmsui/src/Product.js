import {useEffect, useState} from 'react';
import axios from 'axios';
import axiosRetry from 'axios-retry';

axiosRetry(axios,{retries:10,
    retryDelay: () => 2000
})
function Product(){
  const [products, setProducts] = useState([])
  const [product, setProduct] = useState(
    {
        "name": "",
        "description": "",
        "price": "",
        "quantity": ""
    }
  )

  const [editable, setEditable] = useState(false)
  const [currentId, setCurrentId] = useState(null)

     useEffect( () =>{
          fetchProducts()
     },[])

     const displayProducts = ()=>{
        const list =  products.map( product => {
           return <li key={product._id}>    {product.name}    {product.price} {product.description}  &nbsp;&nbsp;&nbsp;
            <button onClick={() =>deleteProduct(product._id)}>Delete</button> &nbsp;&nbsp;&nbsp;
            <button onClick={() =>editProduct(product)}>Edit</button>
            
            </li>
          })
          return list
     }

     const editProduct = (product) =>{
            console.log("product", product)
         
            setProduct( {
                "name": product.name,
                "description": product.description,
                "price": product.price,
                "quantity": product.quantity
            })
            setEditable(true)
            setCurrentId(product._id)
     }

     const deleteProduct = (pid) =>{

        axios.delete(`http://localhost:5000/products/${pid}`).then(
            (response) =>{
                  console.log(response)
                    fetchProducts()
            },
            (error) =>{
                console.log(error)
            }
        )
     }

     const addProduct = () =>{
        console.log("product", product);
        axios.post("http://localhost:5000/products",product).then(
            (response) =>{
                  console.log(response)
                   if(response.data._id){
                    clearValues()
                    fetchProducts()
                   }
            },
            (error) =>{
                console.log(error)
            }
        )
     }

     const clearValues = () =>{
        setProduct( {
            "name": "",
            "description": "",
            "price": "",
            "quantity": ""
        })
     }

     const saveProduct = () =>{
        console.log("save product called");
        console.log(product);
         axios.put(`http://localhost:5000/products/${currentId}`,product).then(
            (response) =>{
                console.log(response);
                       if(response.data._id == currentId){
                        fetchProducts()
                        clearValues()
                        setEditable(false)
                       }
            },
            (error) =>{
                alert("Something went wrong, try again!!");
            }
         )
     }
     const fetchProducts = async () =>{
        let USER_TOKEN = "";
       const response = await fetch("http://localhost:5000/token");
             const token =  await response.text();
             console.log(token);
             USER_TOKEN = token;
             const AuthStr = 'Bearer '.concat(USER_TOKEN);
             const productsResponse = await fetch("http://localhost:5000/products", {
                headers: {
                     Authorization: AuthStr 
                }
              })
             const products = await productsResponse.json();
             setProducts(products);
     }
    //    const fetchProducts = async () =>{

    //     let USER_TOKEN = "";

    //      const tokenResponse = await axios.get("http://localhost:5000/token");

    //      if(tokenResponse){
    //         USER_TOKEN = tokenResponse.data;
    //      }
    //      else{
    //         alert("Token was not generated");
    //      }

    //      if(USER_TOKEN.length > 1){
    //         const AuthStr = 'Bearer '.concat(USER_TOKEN);
    //      const response =  await axios.get("http://localhost:5000/products", { headers: { Authorization: AuthStr }});
    //       if(response instanceof Error){
    //          console.log("error occured");  
    //       }
    //       else{
    //         setProducts(response.data)
    //       }
    //     }
           
    //   }

     

    // const fetchProducts = () =>{

    //      let USER_TOKEN = "";

    //      axios.get("http://localhost:5000/token").then((response) =>{
    //         console.log(response);
    //         USER_TOKEN = response.data;
    //         console.log("USER_TOKEN", USER_TOKEN);
    //      },
    //     (error) =>{
    //         console.log(error);
    //     })
    //      const AuthStr = 'Bearer '.concat(USER_TOKEN);

    //      console.log("AuthStr:", AuthStr);
    //  //  const AuthStr = 'Bearer '.concat("ghfcsrscjfshfscidugccd");

       

    //     axios.get("http://localhost:5000/products", { headers: { Authorization: AuthStr }}).then((response) =>{
    //         console.log(response);
    //        let productList = response.data;
    //        setProducts(productList)
    //   },
    // (error) =>{
    //         console.log(error);
    // })
    //  }
    return(
        <div>
             <h1>Product Component</h1>

 
               <input type="text"  placeholder="enter name" value={product.name} onChange={
                (event) =>{
                        setProduct({...product,name:event.target.value})
                }
               }></input> <br></br><br></br>
                <input type="text"  placeholder="enter description" value={product.description} onChange={
                (event) =>{
                        setProduct({...product,description:event.target.value})
                }
               }></input> <br></br><br></br>
                <input type="text"  placeholder="enter price" value={product.price} onChange={
                (event) =>{
                        setProduct({...product,price:event.target.value})
                }
               }></input> <br></br><br></br>
               <input type="text"  placeholder="enter quantity" value={product.quantity} onChange={
                (event) =>{
                        setProduct({...product,quantity:event.target.value})
                }
               }></input> <br></br><br></br>

               

                

                {editable ? <button onClick={() =>{
     saveProduct()
}}>Save Product</button> : <button onClick={() =>{
    addProduct()
 }}>Add Product</button>}


            <ul>
                {displayProducts()}
            </ul>

            
        </div>
    )

}
export default Product;