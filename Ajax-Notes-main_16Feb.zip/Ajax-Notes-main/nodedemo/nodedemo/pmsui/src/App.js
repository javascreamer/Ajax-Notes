import logo from './logo.svg';
import './App.css';
import Product from './Product';

function App() {
  return (
    <div className="App">
        <h1>App Component</h1>
         <Product></Product>
    </div>
  );
}

export default App;
