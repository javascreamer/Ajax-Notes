fetch("http://localhost:5000/products/67b0ae377aef44db90f05620").then(
  (response) =>{
      return response.json()
  }
).then(
  (response) =>{
    console.log(response);
  }
)